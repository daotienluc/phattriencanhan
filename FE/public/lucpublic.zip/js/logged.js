// toan10, lí 10, hóa 10
document.getElementById("toan10").onclick = function () {
  window.location.href = "./blog_link/toan10-login.html";
};

document.getElementById("vatli10").onclick = function () {
  window.location.href = "./blog_link/li10-login.html";
};

document.getElementById("hoahoc10").onclick = function () {
  window.location.href = "./blog_link/hoa10-login.html";
};

// toán 11, lí 11, hóa 11
document.getElementById("toan11").onclick = function () {
  window.location.href = "./blog_link/toan11-login.html";
};

document.getElementById("vatli11").onclick = function () {
  window.location.href = "./blog_link/li11-login.html";
};

document.getElementById("hoahoc11").onclick = function () {
  window.location.href = "./blog_link/hoa11-login.html";
};

// toán 12, lí 12, hóa 12
document.getElementById("toan12").onclick = function () {
  window.location.href = "./blog_link/toan12-login.html";
};

document.getElementById("vatli12").onclick = function () {
  window.location.href = "./blog_link/li12-login.html";
};

document.getElementById("hoahoc12").onclick = function () {
  window.location.href = "./blog_link/hoa12-login.html";
};
